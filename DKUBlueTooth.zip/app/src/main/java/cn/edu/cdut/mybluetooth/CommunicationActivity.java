package cn.edu.cdut.mybluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import cn.edu.cdut.mybluetooth.utils.ToastUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;


public class CommunicationActivity extends AppCompatActivity {

    private String mAddress;
    private BluetoothAdapter mBlueToothAdapter;
    private BluetoothDevice mDevice;
    private BluetoothSocket mBluetoothSocket;
    private final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");//蓝牙串口服务的UUID
    private ToastUtil mToast;
    private TextView mReceiveContent;
    private TextView mCancelConn;
    private TextView mid;
    private TextView mtemp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.communication_layout);
        Intent intent = getIntent();
        //得到传输过来的设备地址
        mAddress = intent.getStringExtra("address");
        initView();
        initListener();
        //开始连接
        connectDevice();
    }

    private void initView() {
        mToast = new ToastUtil(this);
        mReceiveContent = findViewById(R.id.received_text_content);
        mCancelConn = findViewById(R.id.cancel_conn_btn);
        mid = findViewById(R.id.sheepid);
        mtemp = findViewById(R.id.sheeptemp);
    }

    private void initListener() {
        mCancelConn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    /**
     * 与目标设备建立连接
     */
    private void connectDevice() {

        //获取默认蓝牙设配器
        mBlueToothAdapter = BluetoothAdapter.getDefaultAdapter();
        //通过地址拿到该蓝牙设备device
        mDevice = mBlueToothAdapter.getRemoteDevice(mAddress);
        try {
            //建立socket通信
            mBluetoothSocket = mDevice.createRfcommSocketToServiceRecord(mUUID);
            mBluetoothSocket.connect();
            if (mBluetoothSocket.isConnected()) {
                mToast.showToast("连接成功");
                //开启接收数据的线程
                ReceiveDataThread thread = new ReceiveDataThread();
                thread.start();
            }else{
                mToast.showToast("连接失败，结束重进");
            }
        } catch (IOException e) {
            e.printStackTrace();
            mToast.showToast("连接出错！ ");
            finish();
            try {
                mBluetoothSocket.close();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (mBluetoothSocket.isConnected()) {
                //关闭socket
                mBluetoothSocket.close();
                mBlueToothAdapter = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 负责接收数据的线程
     */
    public class ReceiveDataThread extends Thread{

        private InputStream inputStream;

        public ReceiveDataThread() {
            super();
            try {
                //获取连接socket的输入流
                inputStream = mBluetoothSocket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        @Override
        public void run() {
            super.run();
            while (true){
                try {
                    //每次运行需新生成一个
                    byte[] buffer = new byte[16];
                    inputStream.read(buffer);
                    String a = new String(buffer,0,buffer.length);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //将收到的数据显示在TextView上
                            mReceiveContent.append(a);
                            //System.out.println(a);
                            /**
                             * 注:inputStream控制固定字节读入时并不稳定，读入数据容易出现漏读情况，因此采用其它方法来更新数据
                             * 在每次UI线程中，获取收到数据的最后一行，即最新数据，截取出来进行显示
                             * 由于append会自动换行，因此line_num-2
                             */
                            Layout layout = mReceiveContent.getLayout();
                            String text = mReceiveContent.getText().toString();
                            int line_num = layout.getLineCount();
                            int start = layout.getLineStart(line_num - 2);
                            int end = layout.getLineEnd(line_num - 2);
                            String line = text.substring(start, end);
                            //实时将数据显示更新,这里后期根据单片机数据进行修改
                            mid.setText(line);
                            mtemp.setText(line);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
