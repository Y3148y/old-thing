package com.example.myusb;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.HexDump;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumSet;

//串口通信的接收与发送功能
public class TerminalFragment extends Fragment implements SerialInputOutputManager.Listener {

    //定义 USB 权限状态枚举类
    private enum UsbPermission { Unknown, Requested, Granted, Denied }
    private static final String INTENT_ACTION_GRANT_USB = "com.example.rcusb.GRANT_USB";
//BuildConfig.APPLICATION_ID 获取包名
//    private static final String INTENT_ACTION_GRANT_USB = BuildConfig.APPLICATION_ID + ".GRANT_USB";
    //串口发送数据最大等待时间，默认为 2000ms，
    /*private static final int WRITE_WAIT_MILLIS = 2000;
    private static final int READ_WAIT_MILLIS = 2000;*/
    private static final int WRITE_WAIT_MILLIS = 2000;
    private static final int READ_WAIT_MILLIS = 2000;

    //存储设备ID、端口号、波特率和是否使用 IO 管理器的配置参数
    private int deviceId, portNum, baudRate;
    private boolean withIoManager;

    private final BroadcastReceiver broadcastReceiver;//创建广播接收器，监听 USB 权限请求结果
    private final Handler mainLooper;//创建主线程句柄，用于在 UI 线程中执行任务，用于执行串口数据接收和发送任务
    private TextView receiveText;//创建串口接收数据TextView
//    private ControlLines controlLines;//创建控制线对象，用于显示控制线状态

    private SerialInputOutputManager usbIoManager;//创建串口数据管理器对象，用于管理串口数据
    private UsbSerialPort usbSerialPort;//创建串口对象，用于与串口设备进行通信
    private UsbPermission usbPermission = UsbPermission.Unknown;//创建 USB 权限状态对象，用于记录 USB 权限状态
    private boolean connected = false;//创建连接状态对象，用于记录串口设备连接状态

    public TerminalFragment() {
        //广播器接受对象
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(INTENT_ACTION_GRANT_USB.equals(intent.getAction())) {//检查接收到的广播动作是否匹配预定义的 USB 权限请求动作
                    //intent.getBooleanExtra从广播意图中获取 USB 权限授予状态，
                    //UsbManager.EXTRA_PERMISSION_GRANTED: 系统提供的权限状态键名
                    //false: 默认值，如果获取不到则默认为未授权
                    usbPermission = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                            ? UsbPermission.Granted : UsbPermission.Denied;
                    connect();//连接串口设备//重新调用connect()方法
                }
            }
        };
        mainLooper = new Handler(Looper.getMainLooper());//创建主线程 Handler，用于在后台线程中切换到主线程执行 UI 更新操作
    }

    /*
     * Lifecycle
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceId = getArguments().getInt("device");//获取设备ID
        portNum = getArguments().getInt("port");//获取端口号
        baudRate = getArguments().getInt("baud");//获取波特率
        withIoManager = getArguments().getBoolean("withIoManager");//获取是否使用 IO 管理器的配置参数
    }

    @Override
    public void onStart() {
        super.onStart();
        //注册广播接收器
        ContextCompat.registerReceiver(getActivity(), broadcastReceiver, new IntentFilter(INTENT_ACTION_GRANT_USB), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    public void onStop() {
        //取消注册广播接收器
        getActivity().unregisterReceiver(broadcastReceiver);
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        if(!connected && (usbPermission == UsbPermission.Unknown || usbPermission == UsbPermission.Granted))
            mainLooper.post(this::connect);
    }

    @Override
    public void onPause() {
        if(connected) {
            status("disconnected");
            disconnect();
        }
        super.onPause();
    }

    /*
     * UI
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_terminal, container, false);
        receiveText = view.findViewById(R.id.receive_text);                          // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieveText)); // set as default color to reduce number of spans
        receiveText.setMovementMethod(ScrollingMovementMethod.getInstance());
        TextView sendText = view.findViewById(R.id.send_text);
        View sendBtn = view.findViewById(R.id.send_btn);
        sendBtn.setOnClickListener(v -> send(sendText.getText().toString()));
        View receiveBtn = view.findViewById(R.id.receive_btn);
//        controlLines = new ControlLines(view);
        if(withIoManager) {
            receiveBtn.setVisibility(View.GONE);
        } else {
            receiveBtn.setOnClickListener(v -> read());
        }
        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_terminal, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.clear) {
            receiveText.setText("");
            return true;
        } else if( id == R.id.send_break) {
            if(!connected) {
                Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    usbSerialPort.setBreak(true);
                    Thread.sleep(100); // should show progress bar instead of blocking UI thread
                    usbSerialPort.setBreak(false);
                    SpannableStringBuilder spn = new SpannableStringBuilder();
                    spn.append("send <break>\n");
                    spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorSendText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    receiveText.append(spn);
                } catch(UnsupportedOperationException ignored) {
                    Toast.makeText(getActivity(), "BREAK not supported", Toast.LENGTH_SHORT).show();
                } catch(Exception e) {
                    Toast.makeText(getActivity(), "BREAK failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    /*
     * Serial
     */
    @Override
    public void onNewData(byte[] data) {
        mainLooper.post(() -> {
            receive(data);
        });
    }

    @Override
    public void onRunError(Exception e) {
        mainLooper.post(() -> {
            status("connection lost: " + e.getMessage());
            disconnect();
        });
    }

    /*
     * Serial + UI
     */
    //USB权限请求是异步过程
    private void connect() {
        UsbDevice device = null;
        //通过 UsbManager 获取系统中所有 USB 设备列表，并查找匹配的设备
        UsbManager usbManager = (UsbManager) getActivity().getSystemService(Context.USB_SERVICE);
        for(UsbDevice v : usbManager.getDeviceList().values())
            if(v.getDeviceId() == deviceId)//获取设备ID
                device = v;//获取设备
        if(device == null) {
            status("connection failed: device not found");
            return;
        }
        //获取设备驱动
        UsbSerialDriver driver = UsbSerialProber.getDefaultProber().probeDevice(device);
        /*if(driver == null) {
            driver = CustomProber.getCustomProber().probeDevice(device);//获取自定义驱动
        }*/
        if(driver == null) {
            status("connection failed: no driver for device");
            return;
        }
        //检查指定的端口号是否超出了设备支持的端口数量范围
        //如果端口号过大，则显示错误信息并终止连接过程
        if(portNum >= driver.getPorts().size()) {//portNum：端口索引号0 1 2 3 size：端口数量 3//避免portNum越界
            status("connection failed: not enough ports at device");
            return;
        }
        usbSerialPort = driver.getPorts().get(portNum);//通过索引获取指定端口 portNum：端口索引号
        UsbDeviceConnection usbConnection = usbManager.openDevice(driver.getDevice());//获取设备连接
        //首次尝试连接且没有权限，则请求权限并返回
        if(usbConnection == null && usbPermission == UsbPermission.Unknown && !usbManager.hasPermission(driver.getDevice())) {
            usbPermission = UsbPermission.Requested;//设置权限状态
            //android版本标志
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_MUTABLE : 0;
            Intent intent = new Intent(INTENT_ACTION_GRANT_USB);//创建一个Intent action值为当前包名
            intent.setPackage(getActivity().getPackageName());//设置目标包名，setPackage
            //创建用于发送广播的 PendingIntent
            PendingIntent usbPermissionIntent = PendingIntent.getBroadcast(getActivity(), 0, intent, flags);
            //发起 USB 设备权限请求 系统会显示权限对话框给用户
            usbManager.requestPermission(driver.getDevice(), usbPermissionIntent);
            return;
        }
        //已有权限但连接失败，则显示错误信息并终止连接过程
        if(usbConnection == null) {
            if (!usbManager.hasPermission(driver.getDevice()))
                status("connection failed: permission denied");
            else
                status("connection failed: open failed");
            return;
        }

        //已经获取权限并且连接成功，参数设置和连接初始化代码。
        try {
            usbSerialPort.open(usbConnection);
            try{
                //设置串口通信参数（波特率、数据位、停止位、校验位）
                usbSerialPort.setParameters(baudRate, 8, 1, UsbSerialPort.PARITY_NONE);
            }catch (UnsupportedOperationException e){
                status("unsupport setparameters");
            }
            if(withIoManager) {//启动数据管理器
                //根据 withIoManager 配置决定是否启动 SerialInputOutputManager
                //用于异步读取串口数据
                usbIoManager = new SerialInputOutputManager(usbSerialPort, this);
                usbIoManager.start();
            }
            status("connected");
            connected = true;
//            controlLines.start();//启动控制线
        } catch (Exception e) {
            status("connection failed: " + e.getMessage());
            disconnect();
        }
    }

    //断开连接
    private void disconnect() {
        connected = false;
//        controlLines.stop();
        if(usbIoManager != null) {
            usbIoManager.setListener(null);
            usbIoManager.stop();
        }
        usbIoManager = null;
        try {
            usbSerialPort.close();
        } catch (IOException ignored) {}
        usbSerialPort = null;
    }

    //发送数据  改成公共可见性便于使用
    public void send(String str) {
        if(!connected) {
            Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
             byte[] data = (str + '\n').getBytes();//将字符串 str 与换行符 \n 拼接后转换为字节数组
            //创建 SpannableStringBuilder 对象，用于构建带格式的文本显示
            SpannableStringBuilder spn = new SpannableStringBuilder();
            spn.append("send " + data.length + " bytes\n");
            //字节数据以十六进制格式显示，并添加到 spn 中
            //dumpHexString(byte[] array)->dumpHexString(byte[] array, int offset, int length)
            // 将字节数组的8位字节转换为十六进制字符串+(不足就补空格)result.append(" ");+输出16进制对应字符+result.append(".");
            // 超过8字节换行继续重复以上转换剩下的字符
            spn.append(HexDump.dumpHexString(data)).append("\n");//将实际发送的字节数据转成十六进制字符串
            //设置发送文本的颜色
            spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorSendText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            receiveText.append(spn);//添加发送文本到 receiveText 中
            usbSerialPort.write(data, WRITE_WAIT_MILLIS);
        } catch (Exception e) {
            onRunError(e);
        }
    }

    private void read() {
        if(!connected) {
            Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            byte[] buffer = new byte[8192];
            int len = usbSerialPort.read(buffer, READ_WAIT_MILLIS);//实际读取到的字节数
            //Arrays.copyOf(buffer, len)：创建一个新的字节数组，只包含实际读取的数据（避免处理未使用的缓冲区空间）
            //将处理后的数据传递给 receive() 方法进行显示
            receive(Arrays.copyOf(buffer, len));
        } catch (IOException e) {
            // when using read with timeout, USB bulkTransfer returns -1 on timeout _and_ errors
            // like connection loss, so there is typically no exception thrown here on error
            status("connection lost: " + e.getMessage());
            disconnect();
        }
    }

    //显示接收到的数据
    private void receive(byte[] data) {
        SpannableStringBuilder spn = new SpannableStringBuilder();
        spn.append("receive " + data.length + " bytes\n");
        if(data.length > 0)
            spn.append(HexDump.dumpHexString(data)).append("\n");
        receiveText.append(spn);
    }

    //显示状态信息
    void status(String str) {
        SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
        spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorStatusText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        receiveText.append(spn);
    }
}
